#!/usr/bin/env bash
set -euo pipefail
echo "[CoX-3D] No proprietary weights included. Please obtain SD/VAEs from official sources."
