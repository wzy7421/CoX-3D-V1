
# Data Availability Statement

Public datasets: COCO 2017 (val/test-dev), KITTI (object images). We do not redistribute; please download from official sites. A **minimal** anonymized subset is provided in `examples/sample_data.zip` for verification only.

- COCO: https://cocodataset.org/#download  (CC BY 4.0)
- KITTI: http://www.cvlibs.net/datasets/kitti/  (CC BY-NC-SA 3.0)

In‑house data: contact 2411673@tongji.edu.cn for access requests under academic agreements.
