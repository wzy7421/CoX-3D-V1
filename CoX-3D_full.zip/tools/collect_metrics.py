
import argparse, json, os
from pathlib import Path

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", required=True, help="Root runs directory")
    ap.add_argument("--out", required=True, help="Output JSON path")
    args = ap.parse_args()

    runs_dir = Path(args.runs)
    reports = []
    for report in runs_dir.rglob("report.json"):
        with open(report, "r", encoding="utf-8") as f:
            try:
                data = json.load(f)
                reports.append({"run": str(report.parent.parent), "report": data})
            except Exception as e:
                print(f"Skip {report}: {e}")

    summary = {"count": len(reports), "items": reports}
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)
    print(f"[CoX-3D] Collected {len(reports)} reports -> {args.out}")

if __name__ == "__main__":
    main()
