
# Reproduction Guide

## Minimal demo
```bash
python tools/demo.py --mode ti2d --config configs/cox3d_demo.yaml   --input_text "retro-futuristic hair dryer with matte finish"   --input_image examples/sample_data/images/ref_01.jpg   --save_cam --multi_view 4
```
Outputs under `runs/demo/`.

## Ablations
See configs in `configs/ablation/` and aggregate with:
```bash
python tools/collect_metrics.py --runs runs --out runs/report.json
python tools/visualize_report.py --report runs/report.json --out runs/report.html
```
